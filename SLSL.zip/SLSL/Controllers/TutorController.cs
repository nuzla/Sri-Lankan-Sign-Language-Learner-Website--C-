﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SLSL.Models;
using System.Web.Security;

namespace SLSL.Controllers
{
    public class TutorController : Controller
    {
        //
        // GET: /Tutor/

        public ActionResult Index()
        {
            SLSLLContext db = new SLSLLContext();
            List<Tute> tutes;

            int id = getUserID();

            if (getUserRole().Equals("Tutor"))
            {
               tutes = db.Tutes.Where(a => a.TutorID == id).ToList();
            }
            else
            {
                tutes = db.Tutes.Where(a=> a.Approved == true).ToList();
            }
            return View(tutes);
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create_get()
        {
            return View();
        }


        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_post(Tute tute)
        {
            if (ModelState.IsValid)
            {
                SLSLLContext db = new SLSLLContext();
                var newtute = db.Tutes.Create();

                newtute.TuteName = tute.TuteName;
                newtute.DocPath = tute.DocPath;
                newtute.Approved = false;
                newtute.TutorID = getUserID();

                db.Tutes.Add(newtute);
                db.SaveChanges();

                return RedirectToAction("Index", "Tutor");
            }
            else
            {
                return View();
            }
        }


        public int getUserID()
        {
            SLSLLContext db = new SLSLLContext();

            int id = (from u in db.UserMasters
                      where u.UserName == User.Identity.Name
                      select u.userID).FirstOrDefault();

            return id;
        }

        public String getUserRole()
        {
            SLSLLContext db = new SLSLLContext();

            String role = (from u in db.UserMasters
                      where u.UserName == User.Identity.Name
                      select u.cRole).FirstOrDefault();

            return role;
        }



    }
}
