﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SLSL.Models;

namespace SLSL.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            SLSLLContext db = new SLSLLContext();

            int uid = getUserID();

            Theme theme = db.Themes.Where(s => s.UserID == uid).FirstOrDefault();

            if (theme != null)
            {
                ViewBag.Font = theme.Font;
                ViewBag.Color = theme.BgColor;
            }
            
            return View();
        }


        public int getUserID()
        {
            SLSLLContext db = new SLSLLContext();

            int id = (from u in db.UserMasters
                      where u.UserName == User.Identity.Name
                      select u.userID).FirstOrDefault();

            return id;
        }
    }
}
