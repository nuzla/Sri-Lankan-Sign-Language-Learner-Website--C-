﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SLSL.Models;

namespace SLSL.Controllers
{
    public class GrpVideosController : Controller
    {
        //
        // GET: /GrpVideos/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GrpVideo()
        {
            List<Menu_Video> all = new List<Menu_Video>();
            using (SLSLLContext db = new SLSLLContext())
            {
                all = db.Menu_Video.OrderBy(a => a.ParentID).ToList();
            }
            return View(all);
        }

    }
}
