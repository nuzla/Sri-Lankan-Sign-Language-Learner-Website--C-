﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
using SLSL.Models;

namespace SLSL.Controllers
{
    public class SubmitController : Controller
    {
        //
        // GET: /Submit/

        public ActionResult Index()
        {
            SLSLLContext db = new SLSLLContext();

            int id = getUserID();

            List<Submit> submits = db.Submits.Where(a => a.UserID == id).ToList();
            return View(submits);
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create_get()
        {
            return View();
        }


        public ViewResult submitTute(int id)
        {
            SLSLLContext db = new SLSLLContext();

            ViewBag.tuteID = id;
            return View("Create");
        }




        public int getUserID()
        {
            SLSLLContext db = new SLSLLContext();

            int id = (from u in db.UserMasters
                      where u.UserName == User.Identity.Name
                      select u.userID).FirstOrDefault();

            return id;
        }
    }
}
