﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SLSL.Models;

namespace SLSL.Controllers
{
    public class GrpImagesController : Controller
    {


        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GrpImage()
        {
            List<Menu_Image> all = new List<Menu_Image>();
            using (SLSLLContext db = new SLSLLContext())
            {
                all = db.Menu_Image.OrderBy(a => a.ParentID).ToList();
            }
            return View(all);
        }


    }
}
