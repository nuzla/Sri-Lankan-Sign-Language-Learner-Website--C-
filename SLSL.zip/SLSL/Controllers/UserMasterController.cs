﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SLSL.Models;
using System.Web.Security;

namespace SLSL.Controllers
{
    public class UserMasterController : Controller
    {
        //
        // GET: /UserMaster/

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [AllowAnonymous]
        [HttpPost]
        public ActionResult Login(SLSL.Models.UserMaster user)
        {
            if (ModelState.IsValid)
            {
                if (Isvalid(user.UserName, user.Password))
                {
                    User.IsInRole("Tutor");
                    FormsAuthentication.SetAuthCookie(user.UserName, false);
                    return RedirectToAction("Index", "Home");

                }
                else
                {
                    ModelState.AddModelError("", "Login data id incorrect");

                }
            }
            return View(user);
        }


        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public ActionResult RegisterUser()
        {
            return View();
        }

        [HttpPost]
        [ActionName("RegisterUser")]
        public ActionResult RegisterUser_post(UserMaster user)
        {
            if (ModelState.IsValid)
            {
                SLSLLContext db = new SLSLLContext();
                var newuser = db.UserMasters.Create();

                newuser.UserName = user.UserName;
                newuser.Password = user.Password;
                newuser.firstName = user.firstName;
                newuser.lastName = user.lastName;
                newuser.contactNumber = user.contactNumber;
                newuser.DOB = user.DOB;
                newuser.email = user.email;
                newuser.occupation = user.occupation;
                newuser.cRole = "User";
                

                db.UserMasters.Add(newuser);
                db.SaveChanges();


                int uid = db.UserMasters.Max(a=> a.userID);

                var newtheme = db.Themes.Create();
                newtheme.BgColor = "#ANANAN";
                newtheme.Font = "Hobo Std";
                newtheme.Language = "English";
                newtheme.UserID = uid;

                db.Themes.Add(newtheme);
                db.SaveChanges();


                FormsAuthentication.SetAuthCookie(user.UserName, false);
                return RedirectToAction("Index", "Home");

            }
            else
            {
                return View();
            }
        }

        [HttpPost]
        public JsonResult doesUserNameExist(string UserName)
        {
            
            SLSLLContext db = new SLSLLContext();
            var un = db.UserMasters.FirstOrDefault(u => u.UserName == UserName);

            return Json(un == null);
        }


        private bool Isvalid(string username, string password)
        {
            var SimpleCrypto = new SimpleCrypto.PBKDF2();

            bool isvalid = false;

            using (var db = new SLSLLContext())
            {
                var user = db.UserMasters.FirstOrDefault(u => u.UserName == username);

                if (user != null)
                {
                    //if (user.cPassword == SimpleCrypto.Compute(password))
                    if (user.Password == password)
                    {
                        isvalid = true;
                    }
                }
            }

            return isvalid;
        }
    }
}
