﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SLSL.Models;
using System.Data;

namespace SLSL.Controllers
{
    public class ThemeController : Controller
    {
        //
        // GET: /Theme/

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Edit()
        {

            SLSLLContext db = new SLSLLContext();

            int uid = getUserID();
            Theme theme = db.Themes.Where(s => s.UserID == uid).FirstOrDefault();
            if (theme!= null)
            {
                ViewBag.themeID = theme.ThemeID;
                ViewBag.userID = theme.UserID;
                ViewBag.language = "English";
                ViewBag.color = theme.BgColor;
                ViewBag.font = theme.Font;
            }
           
            return View();
            
        }

        //
        // POST: /Factory/Edit/5

        [HttpPost]
        public ActionResult Edit(Theme theme)
        {
          
                // TODO: Add update logic here
                SLSLLContext db = new SLSLLContext();

                
                    db.Entry(theme).State = EntityState.Modified;
                
                db.SaveChanges();
               
                
                return RedirectToAction("Edit");
           
        }


        public int getUserID()
        {
            SLSLLContext db = new SLSLLContext();

            int id = (from u in db.UserMasters
                      where u.UserName == User.Identity.Name
                      select u.userID).FirstOrDefault();

            return id;
        }

    }
}
