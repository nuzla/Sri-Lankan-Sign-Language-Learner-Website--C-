using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class Menu_ImageMap : EntityTypeConfiguration<Menu_Image>
    {
        public Menu_ImageMap()
        {
            // Primary Key
            this.HasKey(t => new { t.MenuID, t.MenuName, t.URL, t.ParentID });

            // Properties
            this.Property(t => t.MenuID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.MenuName)
                .IsRequired()
                .HasMaxLength(20);

            this.Property(t => t.URL)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.ParentID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("Menu_Image");
            this.Property(t => t.MenuID).HasColumnName("MenuID");
            this.Property(t => t.MenuName).HasColumnName("MenuName");
            this.Property(t => t.URL).HasColumnName("URL");
            this.Property(t => t.ParentID).HasColumnName("ParentID");
        }
    }
}
