using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class SubmitMap : EntityTypeConfiguration<Submit>
    {
        public SubmitMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SubmitID, t.TuteID, t.UserID, t.SubmitPath });

            // Properties
            this.Property(t => t.SubmitID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.TuteID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.UserID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.SubmitPath)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Remarks)
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Submit");
            this.Property(t => t.SubmitID).HasColumnName("SubmitID");
            this.Property(t => t.TuteID).HasColumnName("TuteID");
            this.Property(t => t.UserID).HasColumnName("UserID");
            this.Property(t => t.SubmitPath).HasColumnName("SubmitPath");
            this.Property(t => t.Remarks).HasColumnName("Remarks");

            // Relationships
            this.HasRequired(t => t.Tute)
                .WithMany(t => t.Submits)
                .HasForeignKey(d => d.TuteID);

        }
    }
}
