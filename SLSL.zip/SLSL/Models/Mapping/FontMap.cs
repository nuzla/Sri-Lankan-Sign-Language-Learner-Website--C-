using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class FontMap : EntityTypeConfiguration<Font>
    {
        public FontMap()
        {
            // Primary Key
            this.HasKey(t => new { t.FontID, t.Font1 });

            // Properties
            this.Property(t => t.FontID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Font1)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Fonts");
            this.Property(t => t.FontID).HasColumnName("FontID");
            this.Property(t => t.Font1).HasColumnName("Font");
        }
    }
}
