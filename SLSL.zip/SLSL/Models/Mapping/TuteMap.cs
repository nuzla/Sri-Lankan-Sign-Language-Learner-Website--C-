using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class TuteMap : EntityTypeConfiguration<Tute>
    {
        public TuteMap()
        {
            // Primary Key
            this.HasKey(t => t.TuteID);

            // Properties
            this.Property(t => t.DocPath)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Tute");
            this.Property(t => t.TuteID).HasColumnName("TuteID");
            this.Property(t => t.TuteName).HasColumnName("TuteName");
            this.Property(t => t.DocPath).HasColumnName("DocPath");
            this.Property(t => t.Approved).HasColumnName("Approved");
            this.Property(t => t.TutorID).HasColumnName("TutorID");
        }
    }
}
