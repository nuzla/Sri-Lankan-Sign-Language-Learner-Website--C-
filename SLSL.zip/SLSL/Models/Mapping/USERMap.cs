using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class UserMap : EntityTypeConfiguration<User>
    {
        public UserMap()
        {
            // Primary Key
            this.HasKey(t => t.iAutoIndex);

            // Properties
            this.Property(t => t.cUserName)
                .IsRequired()
                .HasMaxLength(56);

            this.Property(t => t.cPassword)
                .IsRequired()
                .HasMaxLength(20);

            this.Property(t => t.cRole)
                .IsRequired()
                .HasMaxLength(5);

            // Table & Column Mappings
            this.ToTable("User");
            this.Property(t => t.iAutoIndex).HasColumnName("iAutoIndex");
            this.Property(t => t.cUserName).HasColumnName("cUserName");
            this.Property(t => t.cPassword).HasColumnName("cPassword");
            this.Property(t => t.cRole).HasColumnName("cRole");
        }
    }
}
