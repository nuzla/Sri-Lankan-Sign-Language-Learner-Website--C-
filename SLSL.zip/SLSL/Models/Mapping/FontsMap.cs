using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class FontsMap : EntityTypeConfiguration<Fonts>
    {
        public FontsMap()
        {
            // Primary Key
            this.HasKey(t => new { t.FontID, t.Font });

            // Properties
            this.Property(t => t.FontID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.Font)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Fonts");
            this.Property(t => t.FontID).HasColumnName("FontID");
            this.Property(t => t.Font).HasColumnName("Font");
        }
    }
}
