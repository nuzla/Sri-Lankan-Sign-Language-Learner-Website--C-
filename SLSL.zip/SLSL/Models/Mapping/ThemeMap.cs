using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class ThemeMap : EntityTypeConfiguration<Theme>
    {
        public ThemeMap()
        {
            // Primary Key
            this.HasKey(t => t.ThemeID);

            // Properties
            this.Property(t => t.Font)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.BgColor)
                .IsRequired()
                .HasMaxLength(10);

            this.Property(t => t.Language)
                .IsRequired()
                .HasMaxLength(10);

            // Table & Column Mappings
            this.ToTable("Theme");
            this.Property(t => t.ThemeID).HasColumnName("ThemeID");
            this.Property(t => t.Font).HasColumnName("Font");
            this.Property(t => t.BgColor).HasColumnName("BgColor");
            this.Property(t => t.Language).HasColumnName("Language");
            this.Property(t => t.UserID).HasColumnName("UserID");
        }
    }
}
