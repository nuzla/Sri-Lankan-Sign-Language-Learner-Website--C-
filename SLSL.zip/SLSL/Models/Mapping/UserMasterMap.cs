using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace SLSL.Models.Mapping
{
    public class UserMasterMap : EntityTypeConfiguration<UserMaster>
    {
        public UserMasterMap()
        {
            // Primary Key
            this.HasKey(t => t.UserName);

            // Properties
            this.Property(t => t.userID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.Property(t => t.firstName)
                .IsRequired()
                .HasMaxLength(30);

            this.Property(t => t.lastName)
                .IsRequired()
                .HasMaxLength(30);

            this.Property(t => t.occupation)
                .IsRequired()
                .HasMaxLength(20);

            this.Property(t => t.email)
                .HasMaxLength(50);

            this.Property(t => t.UserName)
                .IsRequired()
                .HasMaxLength(56);

            this.Property(t => t.Password)
                .IsRequired()
                .HasMaxLength(20);

            this.Property(t => t.cRole)
                .IsRequired()
                .HasMaxLength(5);

            // Table & Column Mappings
            this.ToTable("UserMaster");
            this.Property(t => t.userID).HasColumnName("userID");
            this.Property(t => t.firstName).HasColumnName("firstName");
            this.Property(t => t.lastName).HasColumnName("lastName");
            this.Property(t => t.DOB).HasColumnName("DOB");
            this.Property(t => t.occupation).HasColumnName("occupation");
            this.Property(t => t.email).HasColumnName("email");
            this.Property(t => t.contactNumber).HasColumnName("contactNumber");
            this.Property(t => t.UserName).HasColumnName("UserName");
            this.Property(t => t.Password).HasColumnName("Password");
            this.Property(t => t.cRole).HasColumnName("cRole");
        }
    }
}
