using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace SLSL.Models
{
    public partial class UserMaster
    {

        public int userID { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public System.DateTime DOB { get; set; }
        public string occupation { get; set; }
        public string email { get; set; }
        public Nullable<decimal> contactNumber { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string cRole { get; set; }
    }

    public partial class RegisterUser
    {
        [Required]
        [Display(Name = "First Name")]
        public string firstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string lastName { get; set; }

        [Required]
        [Display(Name = "Date of Birth")]
        public System.DateTime DOB { get; set; }

        [Required]
        [Display(Name = "Occupation")]
        public string occupation { get; set; }

        [Required]
        [Display(Name = "Email address")]
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }

        [Required]
        [Display(Name = "Contact Number")]
        public Nullable<decimal> contactNumber { get; set; }

        [Required]
        [Display(Name = "User Name")]
        [Remote("doesUserNameExist", "UserMaster", HttpMethod = "POST", ErrorMessage = "User name already exists. Please enter a different user name.")]
        public string UserName { get; set; }

        [Required]
        public string Password { get; set; }
    }
}
