using System;
using System.Collections.Generic;

namespace SLSL.Models
{
    public partial class Font
    {
        public int FontID { get; set; }
        public string Font1 { get; set; }
    }
}
