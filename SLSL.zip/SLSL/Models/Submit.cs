using System;
using System.Collections.Generic;

namespace SLSL.Models
{
    public partial class Submit
    {
        public int SubmitID { get; set; }
        public int TuteID { get; set; }
        public int UserID { get; set; }
        public string SubmitPath { get; set; }
        public string Remarks { get; set; }
        public virtual Tute Tute { get; set; }
    }
}
