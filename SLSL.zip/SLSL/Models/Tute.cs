using System;
using System.Collections.Generic;

namespace SLSL.Models
{
    public partial class Tute
    {
        public Tute()
        {
            this.Submits = new List<Submit>();
        }

        public int TuteID { get; set; }
        public string TuteName { get; set; }
        public string DocPath { get; set; }
        public bool Approved { get; set; }
        public int TutorID { get; set; }
        public virtual ICollection<Submit> Submits { get; set; }
    }
}
