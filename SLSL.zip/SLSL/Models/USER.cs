using System;
using System.Collections.Generic;

namespace SLSL.Models
{
    public partial class User
    {
        public int iAutoIndex { get; set; }
        public string cUserName { get; set; }
        public string cPassword { get; set; }
        public string cRole { get; set; }
    }
}
