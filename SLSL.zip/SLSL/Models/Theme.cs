using System;
using System.Collections.Generic;

namespace SLSL.Models
{
    public partial class Theme
    {
        public int ThemeID { get; set; }
        public string Font { get; set; }
        public string BgColor { get; set; }
        public string Language { get; set; }
        public int UserID { get; set; }
    }
}
