using System;
using System.Collections.Generic;

namespace SLSL.Models
{
    public partial class Menu_Video
    {
        public int MenuID { get; set; }
        public string MenuName { get; set; }
        public string URL { get; set; }
        public int ParentID { get; set; }
    }
}
