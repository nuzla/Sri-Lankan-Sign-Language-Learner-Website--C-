using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using SLSL.Models.Mapping;

namespace SLSL.Models
{
    public partial class SLSLLContext : DbContext
    {
        static SLSLLContext()
        {
            Database.SetInitializer<SLSLLContext>(null);
        }

        public SLSLLContext()
            : base("Name=SLSLLContext")
        {
        }

        public DbSet<Font> Fonts { get; set; }
        public DbSet<Menu_Image> Menu_Image { get; set; }
        public DbSet<Menu_Video> Menu_Video { get; set; }
        public DbSet<Submit> Submits { get; set; }
        public DbSet<sysdiagram> sysdiagrams { get; set; }
        public DbSet<Theme> Themes { get; set; }
        public DbSet<Tute> Tutes { get; set; }
        public DbSet<UserMaster> UserMasters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new FontMap());
            modelBuilder.Configurations.Add(new Menu_ImageMap());
            modelBuilder.Configurations.Add(new Menu_VideoMap());
            modelBuilder.Configurations.Add(new SubmitMap());
            modelBuilder.Configurations.Add(new sysdiagramMap());
            modelBuilder.Configurations.Add(new ThemeMap());
            modelBuilder.Configurations.Add(new TuteMap());
            modelBuilder.Configurations.Add(new UserMasterMap());
        }
    }
}
